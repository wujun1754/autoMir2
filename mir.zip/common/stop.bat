@echo off
rem 可以在vscode中设置快捷键 详情见http://doc.zjh336.cn/#/integrate/hz_autojs_tools_box/help/65 
curl -H "deviceUUID:863818023224810" -H "devicePassword:" http://192.168.66.11:9998/device/execStopProject