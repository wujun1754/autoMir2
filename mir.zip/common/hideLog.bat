@echo off
curl -H "deviceUUID:863818023224810" -H "devicePassword:" http://192.168.66.11:9998/device/stopOnlineLog?deviceUUID=863818023224810